from __future__ import unicode_literals

from django.apps import AppConfig


class DjangoDemoAppConfig(AppConfig):
    name = 'django_demo_app'
