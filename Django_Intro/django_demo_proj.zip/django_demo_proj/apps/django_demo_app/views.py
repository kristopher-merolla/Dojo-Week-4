from django.shortcuts import render
from IPython import embed


# Create your views here.
def index(request):
	myArray = ['1','2','3']
	myDict = {
		"abc" : "xyz"
	}
	context = {
		"name": "shane",
		"occupation" : "instructor",
		'myArray' : myArray,
		'myDict' : myDict
	}

	embed()

	request.session['user_id'] = 5
	request.session['myDict2'] = {
		"def": "ijk"
	}

	return render(request, 'django_demo_app/index.html', context)

